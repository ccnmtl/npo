from settings_shared import *

TEMPLATE_DIRS = (
    "/var/www/epf/epf/templates",
)

MEDIA_ROOT = '/var/www/epf/uploads/'

DEBUG = False
TEMPLATE_DEBUG = DEBUG
