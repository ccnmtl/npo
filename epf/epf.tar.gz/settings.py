from settings_shared import *
